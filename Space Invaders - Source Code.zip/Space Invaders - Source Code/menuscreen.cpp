#include "menuscreen.h"



CMenuScreen::CMenuScreen()
{
}


CMenuScreen::~CMenuScreen()
{
}
